Esta es una soluci�n a un reto de Multiplica Talent.
El requisito es crear una app front-end que pueda facilitar a dise�adores copiar c�digos de color de una lista.

Se ocuparon diversos objetos y c�digos disponibles en DOM y JavaScript. 


En cuanto al uso de frameworks, en realidad �ocup� JavaScript puro!

Se ocup� flex-box.

Dependencias: 
app-colors.html
app-colors.js
app-colors.css


index-self-contained.html
Es una app contenida en s� misma, no requiere ninguna dependencia, salvo por conectividad con el servicio de JSON provisto por el cliente.


Git
https://github.com/cesareoaguirre/challenges/tree/master/multiplica%20talent/colors

Copyrights de terceros
https://commons.wikimedia.org/wiki/File:YouTube_loading_symbol_3_(transparent).gif