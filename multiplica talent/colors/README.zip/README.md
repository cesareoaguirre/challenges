Esta es una soluci�n a un reto de Multiplica Talent.
El requisito es crear una app front-end que pueda facilitar a dise�adores copiar c�digos de color de una lista.

Se ocuparon diversos objetos y c�digos disponibles en DOM y JavaScript. 

Es una app contenida en s� misma, funciona abriendo el index.html y no requiere ninguna dependencia, salvo por conectividad con el servicio de JSON provisto por el cliente.

En cuanto al uso de frameworks, en realidad no, ocup� JavaScript puro!

Varios elementos ocuparon flex-box pues facilita mucho el trabajo.

Git
https://github.com/cesareoaguirre/challenges/tree/master/multiplica%20talent/colors

Copyrights de terceros
https://commons.wikimedia.org/wiki/File:YouTube_loading_symbol_3_(transparent).gif